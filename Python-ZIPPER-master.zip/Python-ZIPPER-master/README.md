# Python-PARENTWARE

To USE the PARENTware out on your machine,
USE AT YOUR OWN RISK, NO WARRANTY

* [PARENT] Run the RSA script to generate two keys, a private and public key

* [TARGET] Run the ransomware script - localRoot .txt files will be encrypted now

* [PARENT] Run the fernet key decryption file to decrypt the decrypt me.txt(be on your desktop) file, this will give you a PUT_ME_ON_DESKtOP.txt file, once you put this on the desktop the ransomware will decrypt the localRoot files in that directory

